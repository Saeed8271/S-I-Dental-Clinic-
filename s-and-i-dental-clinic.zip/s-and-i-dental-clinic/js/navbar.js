/* =========================================================
   S & I DENTAL CLINIC — NAVBAR BEHAVIOR
   navbar.js
   ========================================================= */

(function () {
  const navbar = document.querySelector(".si-navbar");
  const toggle = document.getElementById("siNavToggle");
  const links = document.getElementById("siNavLinks");
  const linkItems = links ? links.querySelectorAll("a") : [];

  if (!navbar) return;

  // Solid background once the user scrolls past the hero threshold
  const SCROLL_THRESHOLD = 24;

  function updateNavbarState() {
    if (window.scrollY > SCROLL_THRESHOLD) {
      navbar.classList.add("is-solid");
    } else {
      navbar.classList.remove("is-solid");
    }
  }

  updateNavbarState();
  window.addEventListener("scroll", updateNavbarState, { passive: true });

  // Mobile menu toggle
  const closeBtn = document.getElementById("siNavClose");

  function closeMenu() {
    links.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
    document.body.classList.remove("nav-open");
  }

  if (toggle && links) {
    toggle.addEventListener("click", () => {
      const isOpen = links.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(isOpen));
      document.body.classList.toggle("nav-open", isOpen);
    });

    if (closeBtn) {
      closeBtn.addEventListener("click", closeMenu);
    }

    linkItems.forEach((link) => {
      link.addEventListener("click", closeMenu);
    });

    // Close menu on escape
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && links.classList.contains("is-open")) {
        closeMenu();
        toggle.focus();
      }
    });
  }
})();
